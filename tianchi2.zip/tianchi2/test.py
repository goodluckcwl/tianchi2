
import cv2
import matplotlib.pyplot as plt

im = cv2.imread('302142585_1.jpg')
plt.imshow(im)
plt.show()