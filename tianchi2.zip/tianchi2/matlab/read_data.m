function data_whole = read_data(filename)
%% This function reads input data.
data = importdata(filename);
textdata = data.textdata;
digitdata = data.data;
digitdata(501:700, end) = 0; % test label is unknow
[num_samples, num_attris] = size(textdata);
% Since the first line is not a sample.
num_samples = num_samples - 1;

%% Preprocess of raw data. Including: 
% 1. Convert data from string format to double format.
% 2. Convert names of tools to digit format.
attris_names = textdata(1, :);

% Find index of 'TOOL' attris;
tool_idxes = [];
for i = 1:num_attris
    if ~isempty(strfind(attris_names{i}, 'TOOL')) || ~isempty(strfind(attris_names{i}, 'Tool'))...
            || ~isempty(strfind(attris_names{i}, 'tool'))
        tool_idxes = [tool_idxes, i];
    end
end

num_tools = length(tool_idxes);
% Store data in group
data_group = cell(1, num_tools);

tool_id_maps = cell(num_tools, 1);
for i = 1:num_tools
    i
    a = tool_idxes(i);
    if i==num_tools
        b = num_attris;
    else
        b = tool_idxes(i + 1) - 1;
    end
    %% Convert str data to digit
    values_str = textdata(2:end, a:b);
    num_feats = size(values_str, 2);
    % Convert tool IDs to digit
    % Firstly, collect all the names of tool id.
    tool_ids = zeros(num_samples, 1);
    tool_id_names = cell(0);
    for j = 1:num_samples
        name = values_str{j, 1};
        if ~find_names_in_cell(tool_id_names, name)
            tool_id_names = [tool_id_names, {name}];
        end
    end
    % Secondly, construct tool id Map.
    tool_id_map = containers.Map;
    for j = 1:length(tool_id_names)
        tool_id_map(tool_id_names{j}) = j;
    end
    tool_id_maps{i} = tool_id_map;
    % Finally, convert tool names to digit codes.
    for j = 1:num_samples
        tool_ids(j) = tool_id_map(values_str{j, 1});
    end
        
    %% Convert attribute values to digit
    x = values_str(:, 2:end);
 
    values = cellfun(@str2num, x(:), 'Uniformoutput', false);
    values_digit = reshape(cell2mat(values), num_samples, []);
    

    if i==num_tools
        % Since the last arrtribute is the label y
        data_group{i}.x = zeros(num_samples, num_feats - 1);
        data_group{i}.x(:, 2:end) = digitdata(:, 1:end - 1);
        data_group{i}.y = digitdata(:, end);
    else
        data_group{i}.x = zeros(num_samples, num_feats);
        data_group{i}.x(:, 2:end) = values_digit;
    end

 
    
    data_group{i}.x(:, 1) = tool_ids;
    data_group{i}.names = attris_names(a:b);
end

%% Combine all groups
% Store data in total
data_whole.x = zeros(num_samples, num_attris - 2);
data_whole.y = zeros(num_samples, 1);
data_whole.names = attris_names(2:end-1);
idx = 1;
for j = 1:length(data_group)
    j
    x = data_group{j}.x;
    len = size(x, 2);
    data_whole.x(:, idx:idx + len - 1) = x;
    idx = idx + len;
end
data_whole.y = data_group{j}.y;

%% Remove missing value
%% Replace missing value by its mean
% In excel, we use -123456 as missing flag.
disp('Replace missing value by its mean...');
X = data_whole.x;
miss_flag = -123456;
[m, n] = find(X==miss_flag);

% Remove missing value and calculate expections
X_remove = X;
X_remove(m, n) = 0;
EX = mean(X_remove);
X_col = X(:);
idx = find(X_col==miss_flag);
X_col(idx) = EX(n);
X = reshape(X_col, num_samples, []);

data_whole.x = X;
data_whole.tool_idxes = tool_idxes - 1;
data_whole.tool_id_maps = tool_id_maps;
data_whole.testA_idx = 501:600;
data_whole.testB_idx = 601:700;
data_whole.train_idx = 1:500;
data_whole.sample_ids = textdata(2:end, 1);

end

function  [is_found] = find_names_in_cell(tool_id_names, name)
    is_found = cellfun(@(x) strcmp(x, name), tool_id_names, 'Uniformoutput', false);
    is_found = sum(cell2mat(is_found));  
    if is_found ~= 0
        is_found = true;
    else
        is_found = false;
    end
end