clc;clear all;

list = importdata('testA-muban.csv');
fid = fopen('testA.csv', 'w');
num = 2.8462;
for i=1:100
    line = [list{1}, ',', num2str(num)];
    fprintf(fid, '%s\n', line);
end
fclose(fid);