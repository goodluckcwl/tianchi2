clc;clear all;
%% This script remove attributes with minor variation
load('../dataset/train.mat');

X = data.x;
[num_samples, num_feat] = size(X);
DX = var(X)';

[DX_down, idx] = sort(DX, 'descend');
idx_del = find(DX<eps);

X(:, idx_del) = [];
names_del = data.names(idx_del);

% Normalization
for i = 1:size(X, 2)
    x = X(:, i);
    L = max(x) - min(x);
    if L<eps
    ''
    end
    X(:, i) = (x - mean(x))/L;
end
Y = data.y(1:500);
T.v = mean(Y);
T.L = max(Y) - min(Y);
Y = (Y - mean(Y))/(max(Y) - min(Y));

train.X = X(1:500, :);
train.Y = Y;
train.T = T;
train.idx_del = idx_del;

test.X = X(501:end, :);

save('../dataset/traindata.mat', 'train', 'test');
