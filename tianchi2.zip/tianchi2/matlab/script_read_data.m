% Train: 1-500 Test A:501-600 TestB:601-700
train_file = '../Data/train.csv';

data = read_data(train_file);

if ~exist('../dataset')
    mkdir(dataset);
end

save('../dataset/train.mat','data');