# -*- coding: utf-8 -*-
# @Author: chenweiliang
# @Date:   2018-01-05 02:26:46
# @Last Modified by:   chenweiliang
# @Last Modified time: 2018-01-06 01:10:32

import numpy as np
import pandas as pd
import os

data_dir = 'results_for_ensemble2'
output_file = 'ensemble_200_6k_nn.csv'
df_list = []
for filename in os.listdir(data_dir):
	df_list.append(pd.read_csv(data_dir + '/' + filename))

results = np.zeros(df_list[0]['prediction'].values.shape)
num_files = len(df_list)
for df in df_list:
	results = results + 1.0/num_files * df['prediction'].values

df_final = pd.DataFrame({'ID': df_list[0]['ID'], 'prediction': results})

df_final.to_csv(output_file, index = False)