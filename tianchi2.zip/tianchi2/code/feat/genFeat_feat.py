
"""
__file__

    genFeat_feat.py

__description__

    This file generates the following features for each run and fold, and for the entire training and testing set.

        1. one-hot encoding of query ids (qid)

__author__

    Chenglong Chen < c.chenglong@gmail.com >

"""

import sys
import cPickle
from sklearn.preprocessing import LabelBinarizer
sys.path.append("../")
from param_config import config


if __name__ == "__main__":

    ###############
    ## Load Data ##
    ###############
    ## load data
    with open(config.processed_train_data_path, "rb") as f:
        dfTotal = cPickle.load(f)
    dfTrain = dfTotal.loc[0:499]
    dfTest = dfTotal.loc[500:]
    ## load pre-defined stratified k-fold index
    with open("%s/stratifiedKFold.kmeansCluster5.pkl" % (config.data_folder), "rb") as f:
            skf = cPickle.load(f)

    #######################
    ## Generate Features ##
    #######################
    print("==================================================")
    print("Generate features...")

    id_name = 'normalized'
    print("For cross-validation...")
    n_sample, n_dim = dfTrain.shape
    for run in range(config.n_runs):
        ## use 20% for training and 80 % for validation
        ## so we switch trainInd and validInd
        for fold, (trainInd, validInd) in enumerate(skf[run]):
            print("Run: %d, Fold: %d" % (run+1, fold+1))
            path = "%s/Run%d/Fold%d" % (config.feat_folder, run+1, fold+1)

            #################
            ## get feat    ##
            #################
            X_train = dfTrain.iloc[trainInd][dfTrain.keys()[1:]]
            X_valid = dfTrain.iloc[validInd][dfTrain.keys()[1:]]
            with open("%s/train.feat.pkl" % (path), "wb") as f:
                cPickle.dump(X_train, f, -1)
            with open("%s/valid.feat.pkl" % (path), "wb") as f:
                cPickle.dump(X_valid, f, -1)
                    
    print("Done.")

    print("For training and testing...")
    path = "%s/All" % config.feat_folder
    ## use full version for X_train
    X_train = dfTrain[dfTrain.keys()[1:]]
    X_test = dfTest[dfTest.keys()[1:]]
    with open("%s/train.feat.pkl" % (path), "wb") as f:
        cPickle.dump(X_train, f, -1)
    with open("%s/test.feat.pkl" % (path), "wb") as f:
        cPickle.dump(X_test, f, -1)
    print("Done.")
    
    print("All Done.")