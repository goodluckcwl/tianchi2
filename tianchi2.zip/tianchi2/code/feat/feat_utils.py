import pandas as pd
import numpy as np

def tool_class_coding(df):
    tool_keys = [x for x in df.keys() if x.find('TOOL') == 0
                 or x.find('tool') == 0 or x.find('Tool') == 0]
    for key in tool_keys:
        x = pd.get_dummies(df[key])
        ids = dict()
        for v in df[key]:
            if not ids.has_key(v):
                ids[v] = len(ids.keys())
        values = np.zeros([df.shape[0], 1])
        for i, v in enumerate(df[key]):
            values[i] = ids[v]
        df[key] = values
    return df


def fix_missing_value(df):
    keys = df.keys()
    tool_idx = [(i, x) for i, x in enumerate(keys.values) if x.find('TOOL') == 0
     or x.find('tool') == 0 or x.find('Tool') == 0]
    for i, (idx, key) in enumerate(tool_idx):
        # Get the tool specific sub dataframe
        if i  == len(tool_idx) - 1:
            df_tool = df[keys[idx + 1: df.shape[1]]]
        else:
            df_tool = df[keys[idx + 1: tool_idx[i + 1][0]]]

        # For each tool specific sub dataframe
        key_range = range(max(df[key].values.astype('int')) + 1)
        # Split the data into groups according to the tool label
        for key_label in key_range:
            df_tool_label = df_tool[df[key] == key_label]
            # Find missing value
            for name in df_tool_label.keys():
                missing_idx = [ix for ix, x in enumerate(df_tool_label[name]) if x == '']
                valid_idx = [ix for ix, x in enumerate(df_tool_label[name]) if not x == '']
                if len(missing_idx) == 0:
                    ''
                elif not len(valid_idx) == 0:
                    values = df_tool_label[name].values
                    # Fix missing value
                    values[missing_idx] = np.mean(values[valid_idx])
                    # Save Results
                    df.loc[df_tool_label.index, name] = values
                # All values are missing. Replace by global mean value.
                else:
                    global_valid_idx = [ix for ix, x in enumerate(df_tool[name]) if not x == '']
                    global_mu = np.mean(df_tool[name].values[global_valid_idx])
                    df.loc[df_tool_label.index, name] = global_mu


    return df

def remove_date_attris(dfTotal):
    keys = []
    for k in dfTotal.keys()[1:]:
        count = 0
        for v in dfTotal[k]:
            if v == '':
                continue
            if len(str(int(v))) < 4:
                continue
            if str(int(v))[0:4].find('2017') == 0 or str(int(v))[0:4].find('2016') == 0:
                count = count + 1
            if count > 5:
                keys.append(k)
                break


    dfTotal = dfTotal.drop(keys, 1)
    return dfTotal

def remove_attris(dfTotal, std_thresh):
    print dfTotal.keys()
    x = dfTotal.std()[1:]
    drop_idx = [i + 1 for i, v in enumerate(x) if v < std_thresh]
    dfTotal = dfTotal.drop(dfTotal.keys()[drop_idx], 1)
    return dfTotal

def normalize_attris(df):
    # To float
    for k in df.keys():
        trans = dict()
        if not k == 'ID' and not k == 'Y':
            df.loc[:, k] = df[k].values.astype('float')
            v_max = np.max(df[k].values)
            v_min = np.min(df[k].values)
            v_mu = np.mean(df[k].values)
            v_median = np.median(df[k].values)
            # Normalize
            df.loc[:, k] = (df[k].values - v_median)/np.max([(v_max - v_min), 1e-16])
        if k == 'Y':
            v_median = np.median(df.loc[0:499, k])
            v_max = np.max(df.loc[0:499, k])
            v_min = np.min(df.loc[0:499, k])
            df.loc[0:499, k] = (df.loc[0:499, k].values - v_median)/np.max([(v_max - v_min), 1e-16])
            trans['L'] = v_max - v_min
            trans['v'] = v_median
    return df, trans