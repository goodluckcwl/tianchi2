
"""
__file__

    preprocess.py

__description__

    This file preprocesses data.

__author__

    Chenglong Chen
    
"""

import sys
import cPickle
import numpy as np
import pandas as pd
sys.path.append("../")
from param_config import config
from feat_utils import *

###############
## Load Data ##
###############
print("Load data...")

dfTrain = pd.read_csv(config.original_train_data_path).fillna("")
dfTest = pd.read_csv(config.original_testA_data_path).fillna("")
dfTestB = pd.read_csv(config.original_testB_data_path).fillna("")
# number of train/test samples
num_train, num_test, num_testB = dfTrain.shape[0], dfTest.shape[0], dfTestB.shape[0]
dfTest['Y'] = np.zeros((num_test))
dfTestB['Y'] = np.zeros((num_testB))
dfTotal = pd.concat([dfTrain, dfTest, dfTestB])
dfTotal = dfTotal.reset_index()
dfTotal = dfTotal.drop('index',1)
print("Done.")


######################
## Pre-process Data ##
######################
print("Pre-process data...")

## convert tool label to digit
print("Convert tool label to digit-------------------")
dfTotal = tool_class_coding(dfTotal)

## Remove date attribute
print('Remove date attribute-------------------------')
print('Original feature dim:%d' % (dfTotal.shape[1]-2))
dfTotal = remove_date_attris(dfTotal)
print('Processed feature dim:%d' % (dfTotal.shape[1]-2))

## fix missing value
print('Fix missing value------------------------------')
dfTotal = fix_missing_value(dfTotal)


## Normalize
print('Normalize---------------------------------------')
dfTotal, trans = normalize_attris(dfTotal)

## Remove attributes with minor std
print('Remove attributes with minor std----------------')
print('Original feature dim:%d' % (dfTotal.shape[1]-2))
dfTotal = remove_attris(dfTotal, config.std_thresh)
print('Processed feature dim:%d' % (dfTotal.shape[1]-2))
print("Done.")


###############
## Save Data ##
###############
print("Save data...")

with open(config.processed_train_data_path, "wb") as f:
    cPickle.dump(dfTotal, f, -1)
with open(config.processed_train_trans_path, "wb") as f:
    cPickle.dump(trans, f, -1)

    
print("Done.")


"""
## pos tag text
dfTrain = dfTrain.apply(pos_tag_text, axis=1)
dfTest = dfTest.apply(pos_tag_text, axis=1)
with open(config.pos_tagged_train_data_path, "wb") as f:
    cPickle.dump(dfTrain, f, -1)
with open(config.pos_tagged_test_data_path, "wb") as f:
    cPickle.dump(dfTest, f, -1)
print("Done.")
"""