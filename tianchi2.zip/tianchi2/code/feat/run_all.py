
"""
__file__

	run_all.py

__description___
	
	This file generates all the features in one shot.

__author__

	Chenglong Chen < c.chenglong@gmail.com >

"""

import os

#################
## Preprocesss ##
#################
#### preprocess data
cmd = "python ./preprocess.py"
os.system(cmd)

# #### generate kfold
cmd = "python ./gen_kfold.py"
os.system(cmd)

#######################
## Generate features ##
#######################
#### query id
cmd = "python ./genFeat_feat.py"
os.system(cmd)

