
"""
__file__

    ensemble_selection.py

__description__

    This file contains ensemble selection module.

__author__

    Chenglong Chen < c.chenglong@gmail.com >

"""


import csv
import sys
import numpy as np
import pandas as pd
import cPickle
from utils import getScore, getTestScore
from ml_metrics import quadratic_weighted_kappa
from hyperopt import fmin, tpe, hp, STATUS_OK, STATUS_FAIL, Trials
sys.path.append("../")
from param_config import config

########################
## Ensemble Selection ##
########################
def ensembleSelectionPrediction(model_folder, best_bagged_model_list, best_bagged_model_weight, cdf, cutoff=None, ensemble_by_weight=False):
    num_model = np.sum([len(m) for m in best_bagged_model_list ])
    bagging_size = len(best_bagged_model_list)
    for bagging_iter in range(bagging_size):
        w_ens = 0
        iter = 0
        for model,w in zip(best_bagged_model_list[bagging_iter], best_bagged_model_weight[bagging_iter]):
            iter += 1
            pred_file = "%s/All/test.raw.pred.%s.csv" % (model_folder, model)
            path = "%s/All" % (config.feat_folder)
            this_p_valid = pd.read_csv(pred_file)["prediction"].values
            this_w = w
            if iter == 1:
                p_ens_valid = np.zeros((this_p_valid.shape[0]),dtype=float)
                with open(config.processed_train_data_path, "rb") as f:
                    id_test = cPickle.load(f).loc[500:,'ID']
                id_test = id_test.values
            if ensemble_by_weight:
                p_ens_valid = (w_ens * p_ens_valid + this_w * this_p_valid) / (w_ens + this_w)
            else:
                p_ens_valid = p_ens_valid + 1.0/num_model * this_p_valid
            w_ens += this_w
        if bagging_iter == 0:
            p_ens_valid_bag = p_ens_valid
        else:
            if ensemble_by_weight:
                p_ens_valid_bag = (bagging_iter * p_ens_valid_bag + p_ens_valid) / (bagging_iter+1.)
            else:
                p_ens_valid_bag = p_ens_valid_bag + p_ens_valid

    output = pd.DataFrame({"ID": id_test, "prediction": p_ens_valid_bag})
    return output


def ensembleSelectionObj(param, p1_list, weight1, p2_list, true_label_list, cdf_list, numValidMatrix):

    weight2 = param['weight2']
    kappa_cv = np.zeros((config.n_runs, config.n_folds), dtype=float)
    for run in range(config.n_runs):
        for fold in range(config.n_folds):
            numValid = numValidMatrix[run][fold]
            p1 = p1_list[run,fold,:numValid]
            p2 = p2_list[run,fold,:numValid]
            true_label = true_label_list[run,fold,:numValid]
            p_ens = (weight1 * p1 + weight2 * p2) / (weight1 + weight2)
            kappa_cv[run][fold] = np.sum(np.power(p_ens - true_label, 2))/numValid
    kappa_cv_mean = np.mean(kappa_cv)
    return {'loss': kappa_cv_mean, 'status': STATUS_OK}


def ensembleSelection(feat_folder, model_folder, model_list, cdf, cdf_test, subm_prefix,
                 hypteropt_max_evals=10, w_min=-1., w_max=1.,
                  bagging_replacement=False, bagging_fraction=0.5, bagging_size=10, init_top_k=5, prunning_fraction=0.2,
                      ensemble_by_weight=True):
    ## load all the prediction
    maxNumValid = 12000
    pred_list_valid = np.zeros((len(model_list), config.n_runs, config.n_folds, maxNumValid), dtype=float)
    Y_list_valid = np.zeros((config.n_runs, config.n_folds, maxNumValid), dtype=float)
    numValidMatrix = np.zeros((config.n_runs, config.n_folds), dtype=int)
    p_ens_list_valid = np.zeros((config.n_runs, config.n_folds, maxNumValid), dtype=float)

    numTest = 22513
    
    ## model to idx
    model2idx = dict()
    kappa_list = dict()
    for i,model in enumerate(model_list): 
        model2idx[model] = i
        kappa_list[model] = 0
    print("============================================================")
    print("Load model...")
    for model in model_list:
        model_id = model2idx[model]
        print("model: %s" % model)
        kappa_cv = np.zeros((config.n_runs, config.n_folds), dtype=float)
        ## load cvf
        for run in range(config.n_runs):
            for fold in range(config.n_folds):
                path = "%s/Run%d/Fold%d" % (model_folder, run+1, fold+1)
                pred_file = "%s/valid.raw.pred.%s.csv" % (path, model)

                this_p_valid = pd.read_csv(pred_file, dtype=float)
                numValidMatrix[run][fold] = this_p_valid.shape[0]           
                pred_list_valid[model_id,run,fold,:numValidMatrix[run][fold]] = this_p_valid["prediction"].values
                Y_list_valid[run,fold,:numValidMatrix[run][fold]] = this_p_valid["target"].values
                # Calculate rmse
                kappa_cv[run][fold] = np.sum(np.power(pred_list_valid[model_id,run,fold,:numValidMatrix[run][fold]]
                                                      - Y_list_valid[run,fold,:numValidMatrix[run][fold]], 2)) / numValidMatrix[run][fold]

        print("kappa: %.6f" % np.mean(kappa_cv))
        kappa_list[model] = np.mean(kappa_cv)
    sorted_models = sorted(kappa_list.items(), key=lambda x: x[1], reverse=True)[::-1]
        
    # greedy ensemble
    print("============================================================")
    print("Perform ensemble selection...")
    best_bagged_model_list = [[]]*bagging_size
    best_bagged_model_weight = [[]]*bagging_size
    num_model = len(model_list)
    #print bagging_size
    for bagging_iter in range(bagging_size):
        rng = np.random.RandomState(2015 + 100 * bagging_iter)
        if bagging_replacement:
            sampleSize = int(num_model*bagging_fraction)
            index_base = rng.randint(num_model, size=sampleSize)
        else:
            randnum = rng.uniform(size=num_model)
            index_base = [i for i in range(num_model) if randnum[i] < bagging_fraction]
        this_sorted_models = [sorted_models[i] for i in sorted(index_base)]

        #print this_model_list
        best_model_list = []
        best_model_weight = []
        best_kappa = 0
        best_model = None
        p_ens_list_valid_tmp = np.zeros((config.n_runs, config.n_folds, maxNumValid), dtype=float)
        #### initialization
        w_ens, this_w = 0, 1.0

        if init_top_k > 0:
            cnt = 0
            kappa_cv = np.zeros((config.n_runs, config.n_folds), dtype=float)
            for model,kappa in this_sorted_models:
                if cnt >= init_top_k:
                    continue
                print("add to the ensembles the following model")
                print("model: %s" % model)
                print("kappa: %.6f" % kappa)
                this_p_list_valid = pred_list_valid[model2idx[model]]
                for run in range(config.n_runs):
                    for fold in range(config.n_folds):
                        numValid = numValidMatrix[run][fold]
                        if cnt == 0:
                            this_w = 1.0
                        else:
                            pass
                        # Ensemble
                        if not ensemble_by_weight:
                            p_ens_list_valid_tmp[run, fold, :numValid] = p_ens_list_valid_tmp[run, fold,:numValid] + 1.0/min(init_top_k, num_model) * this_p_list_valid[run, fold,:numValid]
                        else:
                            p_ens_list_valid_tmp[run,fold,:numValid] = (w_ens * p_ens_list_valid_tmp[run,fold,:numValid] + this_w * this_p_list_valid[run,fold,:numValid]) / (w_ens + this_w)
                        #p_ens_list_valid_tmp[run,fold,:numValid] = p_ens_list_valid_tmp[run,fold,:numValid].argsort().argsort()
                        if cnt == init_top_k - 1:
                            true_label = Y_list_valid[run,fold,:numValid]
                            # Calculate rmse
                            kappa_cv[run][fold] = np.sum(np.power(p_ens_list_valid_tmp[run,fold,:numValid] - true_label, 2))/numValid
                best_model_list.append(model)
                best_model_weight.append(this_w)
                w_ens += this_w
                cnt += 1
            print("Init kappa: %.6f (%.6f)" % (np.mean(kappa_cv), np.std(kappa_cv)))
        #### ensemble selection with replacement
        iter = 0
        best_kappa = np.mean(kappa_cv)
        while ensemble_by_weight:
            iter += 1
            for model,_ in this_sorted_models:
                this_p_list_valid = pred_list_valid[model2idx[model]]

                ## hyperopt for the best weight
                trials = Trials()
                param_space = {
                    'weight2': hp.uniform('weight2', w_min, w_max)
                }
                obj = lambda param: ensembleSelectionObj(param, p_ens_list_valid_tmp, 1., this_p_list_valid, Y_list_valid, None, numValidMatrix)
                best_params = fmin(obj,
                                   param_space, algo=tpe.suggest,
                                   trials=trials, max_evals=hypteropt_max_evals)
                this_w = best_params['weight2']
                this_w *= w_ens
                # all the current prediction to the ensemble
                kappa_cv = np.zeros((config.n_runs, config.n_folds), dtype=float)
                for run in range(config.n_runs):
                    for fold in range(config.n_folds):
                        numValid = numValidMatrix[run][fold]
                        p1 = p_ens_list_valid_tmp[run,fold,:numValid]
                        p2 = this_p_list_valid[run,fold,:numValid]
                        true_label = Y_list_valid[run,fold,:numValid]
                        p_ens = (w_ens * p1 + this_w * p2) / (w_ens + this_w)
                        kappa_cv[run][fold] = np.sum(np.power(p_ens - true_label, 2))/numValid
                if np.mean(kappa_cv) < best_kappa:
                    best_kappa, best_model, best_weight = np.mean(kappa_cv), model, this_w
            if best_model == None:
                break
            print("Iter: %d" % iter)
            print("    model: %s" % best_model)
            print("    weight: %s" % best_weight)
            print("    kappa: %.6f" % best_kappa)

            best_model_list.append(best_model)
            best_model_weight.append(best_weight)
            # valid
            this_p_list_valid = pred_list_valid[model2idx[best_model]]
            for run in range(config.n_runs):
                for fold in range(config.n_folds):
                    numValid = numValidMatrix[run][fold]
                    p_ens_list_valid_tmp[run,fold,:numValid] = (w_ens * p_ens_list_valid_tmp[run,fold,:numValid] + best_weight * this_p_list_valid[run,fold,:numValid]) / (w_ens + best_weight)
            best_model = None
            w_ens += best_weight
            
        kappa_cv = np.zeros((config.n_runs, config.n_folds), dtype=float)
        cutoff = np.zeros((3), dtype=float)
        for run in range(config.n_runs):
            for fold in range(config.n_folds):
                numValid = numValidMatrix[run][fold]
                true_label = Y_list_valid[run,fold,:numValid]
                p_ens_list_valid[run,fold,:numValid] = (bagging_iter * p_ens_list_valid[run,fold,:numValid] + p_ens_list_valid_tmp[run,fold,:numValid]) / (bagging_iter+1.)
                kappa_cv[run][fold] = np.sum(np.power(p_ens_list_valid[run,fold,:numValid] - true_label, 2))/numValid

        print( "Bag %d, kappa: %.6f (%.6f)" % (bagging_iter+1, np.mean(kappa_cv), np.std(kappa_cv)) )
        best_kappa_mean = np.mean(kappa_cv)
        best_kappa_std = np.std(kappa_cv)
        best_bagged_model_list[bagging_iter] = best_model_list
        best_bagged_model_weight[bagging_iter] = best_model_weight

        ## save the current prediction
        # use cdf
        output = ensembleSelectionPrediction(model_folder, best_bagged_model_list[:(bagging_iter+1)], best_bagged_model_weight[:(bagging_iter+1)], cdf_test, ensemble_by_weight)
        sub_fileA = "%s_[InitTopK%d]_[BaggingSize%d]_[BaggingFraction%s]_[Mean%.6f]_[Std%.6f]_[TestA].csv" % (subm_prefix, init_top_k, bagging_iter+1, bagging_fraction, best_kappa_mean, best_kappa_std)
        output.loc[:99].to_csv(sub_fileA, index=False)
        sub_fileB = "%s_[InitTopK%d]_[BaggingSize%d]_[BaggingFraction%s]_[Mean%.6f]_[Std%.6f]_[TestB].csv" % (subm_prefix, init_top_k, bagging_iter+1, bagging_fraction, best_kappa_mean, best_kappa_std)
        output.loc[100:].to_csv(sub_fileB, index=False)
    return best_kappa_mean, best_kappa_std, best_bagged_model_list, best_bagged_model_weight