import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from torch.autograd import Variable
import scipy.io as sio
import numpy as np

class DNN_Net(torch.nn.Module):
    def __init__(self, X_train, Y_train, num_feats, params):
        super(DNN_Net, self).__init__()
        self.modules = []
        self.nb_epochs = params['nb_epochs']
        self.batch_size = params['batch_size']
        hidden_layers = params['hidden_layers']
        layer_idx = 1
        while hidden_layers > 0:
            hidden_units = params['hidden_units']
            if layer_idx == 1:
                fc = nn.Linear(num_feats, hidden_units)
                self.modules.add(fc)
            else:
                fc = nn.Linear(hidden_units, hidden_units)
                self.modules.add(fc)
            if params['hidden_activation'] == 'relu':
                self.modules.add(nn.ReLU())
            if params['hidden_activation'] == 'prelu':
                self.modules.add(nn.PReLU())
            hidden_dropout = params['hidden_dropout']
            self.modules.add(nn.Dropout(hidden_dropout))
            layer_idx = layer_idx + 1

        self.X = X_train
        self.Y = Y_train
        nb_samples = X_train.shape[0]
        ind = range(0, nb_samples, 1)
        ind = np.random.shuffle(ind)
        self.dataloader = []
        num_batch = np.ceil(nb_samples/self.batch_size)
        for i in range(0, num_batch, 1):
            if i == num_batch - 1:
                I = ind[i * self.batch_size:]
            else:
                I = ind[i*self.batch_size:(i+1)*self.batch_size]
            self.dataloader.append([self.X[ind[I]], self.Y[ind[I]]])

    def get_dataloader(self):
        return self.dataloader

    def forward(self, x):
        for m in self.modules:
            x = m.forward(x)
        return x


    def weights_init(self, m):
        if isinstance(m, nn.Conv2d):
            nn.init.xavier_normal(m.weight)
            if isinstance(m.bias, nn.Parameter):
                nn.init.constant(m.bias, 0)
        elif isinstance(m, nn.Linear):
            nn.init.xavier_normal(m.weight)
            nn.init.constant(m.bias, 0)

data_dir = '../dataset/traindata.mat'
data = sio.loadmat(data_dir)
train = data['train']
X = train['X'][0][0]
Y = train['Y'][0][0]
test = data['test']
test_X = test['X'][0][0]
num_samples, num_feats = X.shape

net = DNN_Net(num_feats)
print net
optimizer = torch.optim.SGD(net.parameters(),lr=0.01)
loss_func = torch.nn.MSELoss()
plt.ion()

X_in = Variable(torch.FloatTensor(X))
Y_in = Variable(torch.FloatTensor(Y))
X_in, Y_in = X_in.cuda(), Y_in.cuda()
for i in range(1, 10000, 1):
    pred = net(X_in)




