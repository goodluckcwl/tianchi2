"""
__file__

    train_model.py

__description__

    This file trains various models.

__author__

    Chenglong Chen < c.chenglong@gmail.com >

"""

import sys
import csv
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
from torch.autograd import Variable
import cPickle
import numpy as np
import pandas as pd
import xgboost as xgb
from scipy.sparse import hstack
## sklearn
from sklearn.base import BaseEstimator
from sklearn.datasets import load_svmlight_file, dump_svmlight_file
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.linear_model import Ridge, Lasso, LassoLars, ElasticNet
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
from sklearn.ensemble import GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.pipeline import Pipeline
## hyperopt
from hyperopt import hp
from hyperopt import fmin, tpe, hp, STATUS_OK, Trials
## cutomized module
from model_library_config import feat_folders, feat_names, param_spaces, int_feat

sys.path.append("../")
from param_config import config
from ml_metrics import quadratic_weighted_kappa
from utils import *

global trial_counter
global log_handler

## libfm
libfm_exe = "../../libfm-1.40.windows/libfm.exe"

## rgf
call_exe = "../../rgf1.2/test/call_exe.pl"
rgf_exe = "../../rgf1.2/bin/rgf.exe"

output_path = "../../Output/%f" % config.std_thresh

### global params
## you can use bagging to stabilize the predictions
bootstrap_ratio = 1
bootstrap_replacement = False
bagging_size = 1

ebc_hard_threshold = False
verbose_level = 1


class DNN_Net(torch.nn.Module):
    def __init__(self, X_train, Y_train, num_feats, params, dims):
        super(DNN_Net, self).__init__()
        self.mylayers = []
        self.nb_epochs = params['nb_epoch']
        self.batch_size = params['batch_size']

        self.fc1 = nn.Linear(num_feats, dims[0])
        self.prelu1 = nn.PReLU()
        self.fc2 = nn.Linear(dims[0], dims[1])
        self.prelu2 = nn.PReLU()
        self.fc3 = nn.Linear(dims[1], dims[2])
        self.prelu3 = nn.PReLU()
        self.fc4 = nn.Linear(dims[2], dims[3])
        self.prelu4 = nn.PReLU()
        self.pred = nn.Linear(dims[3], 1)

        self.X = X_train
        self.Y = Y_train


    def get_dataloader(self):
        nb_samples = self.X.shape[0]
        ind = np.array(range(0, nb_samples, 1))
        np.random.shuffle(ind)
        self.dataloader = []
        num_batch = int(np.ceil(nb_samples*1.0/self.batch_size))
        for i in range(0, num_batch, 1):
            if i == num_batch - 1:
                I = ind[i * self.batch_size:]
            else:
                I = ind[i*self.batch_size:(i+1)*self.batch_size]
            self.dataloader.append([self.X[ind[I]], self.Y[ind[I]]])
        return self.dataloader

    def forward(self, x):
        x = F.dropout(x, 0.5)
        x = self.prelu1(self.fc1(x))
        x = F.dropout(x, 0.1)
        x = self.prelu2(self.fc2(x))
        x = F.dropout(x, 0.1)
        x = self.prelu3(self.fc3(x))
        x = F.dropout(x, 0.1)
        x = self.prelu4(self.fc4(x))
        x = F.dropout(x, 0.1)
        x = self.pred(x)
        return x



    def weights_init(self, m):
        if isinstance(m, nn.Conv2d):
            nn.init.xavier_normal(m.weight)
            if isinstance(m.bias, nn.Parameter):
                nn.init.constant(m.bias, 0)
        elif isinstance(m, nn.Linear):
            nn.init.xavier_normal(m.weight)
            nn.init.constant(m.bias, 0)

#### warpper for hyperopt for logging the training reslut
# adopted from
#
def hyperopt_wrapper(param, feat_folder, feat_name):
    global trial_counter
    global log_handler
    trial_counter += 1

    # convert integer feat
    for f in int_feat:
        if param.has_key(f):
            param[f] = int(param[f])

    print("------------------------------------------------------------")
    print "Trial %d" % trial_counter

    print("        Model")
    print("              %s" % feat_name)
    print("        Param")
    for k, v in sorted(param.items()):
        print("              %s: %s" % (k, v))
    print("        Result")
    print("                    Run      Fold      Bag      Kappa      Shape")

    ## evaluate performance
    kappa_cv_mean, kappa_cv_std = hyperopt_obj(param, feat_folder, feat_name, trial_counter)

    ## log
    var_to_log = [
        "%d" % trial_counter,
        "%.6f" % kappa_cv_mean,
        "%.6f" % kappa_cv_std
    ]
    for k, v in sorted(param.items()):
        var_to_log.append("%s" % v)
    writer.writerow(var_to_log)
    log_handler.flush()

    return {'loss': -kappa_cv_mean, 'attachments': {'std': kappa_cv_std}, 'status': STATUS_OK}


#### train CV and final model with a specified parameter setting
def hyperopt_obj(param, feat_folder, feat_name, trial_counter):
    kappa_cv = np.zeros((config.n_runs, config.n_folds), dtype=float)
    for run in range(1, config.n_runs + 1):
        for fold in range(1, config.n_folds + 1):
            rng = np.random.RandomState(2015 + 1000 * run + 10 * fold)

            #### all the path
            path = "%s/Run%d/Fold%d" % (feat_folder, run, fold)
            save_path = "%s/Run%d/Fold%d" % (output_path, run, fold)
            if not os.path.exists(save_path):
                os.makedirs(save_path)
            # feat
            feat_train_path = "%s/train.feat.pkl" % path
            feat_valid_path = "%s/valid.feat.pkl" % path

            # raw prediction path (rank)
            raw_pred_valid_path = "%s/valid.raw.pred.%s_[Id@%d].csv" % (save_path, feat_name, trial_counter)
            rank_pred_valid_path = "%s/valid.pred.%s_[Id@%d].csv" % (save_path, feat_name, trial_counter)

            ## load feat
            with open(feat_train_path, "rb") as f:
                X_train = cPickle.load(f)
            with open(feat_valid_path, "rb") as f:
                X_valid = cPickle.load(f)
            numTrain, numValid = X_train.shape[0], X_valid.shape[0]
            num_feats = X_valid.shape[1] - 1
            labels_valid = X_valid['Y']
            X_valid = X_valid[X_valid.keys()[:num_feats]]
            labels_train = X_train['Y']
            X_train = X_train[X_train.keys()[:num_feats]]

            ##############
            ## Training ##
            ##############
            ## you can use bagging to stabilize the predictions
            preds_bagging = np.zeros((numValid, bagging_size), dtype=float)
            for n in range(bagging_size):
                if bootstrap_replacement:
                    sampleSize = int(numTrain * bootstrap_ratio)
                    index_base = rng.randint(numTrain, size=sampleSize)
                    index_meta = [i for i in range(numTrain) if i not in index_base]
                else:
                    randnum = rng.uniform(size=numTrain)
                    index_base = [i for i in range(numTrain) if randnum[i] < bootstrap_ratio]
                    index_meta = [i for i in range(numTrain) if randnum[i] >= bootstrap_ratio]

                if param.has_key("booster"):
                    dvalid_base = xgb.DMatrix(X_valid, label=labels_valid)
                    dtrain_base = xgb.DMatrix(X_train.iloc[index_base], label=labels_train.iloc[index_base])

                    watchlist = []
                    if verbose_level >= 2:
                        watchlist = [(dtrain_base, 'train'), (dvalid_base, 'valid')]

                ## various models
                if param["task"] in ["regression", "ranking"]:
                    ## regression & pairwise ranking with xgboost
                    bst = xgb.train(param, dtrain_base, param['num_round'], watchlist, feval='rmse')
                    pred = bst.predict(dvalid_base)

                elif param["task"] in ["softmax"]:
                    ## softmax regression with xgboost
                    bst = xgb.train(param, dtrain_base, param['num_round'], watchlist, feval=evalerror_softmax_valid)
                    pred = bst.predict(dvalid_base)
                    w = np.asarray(range(1, numOfClass + 1))
                    pred = pred * w[np.newaxis, :]
                    pred = np.sum(pred, axis=1)

                elif param["task"] in ["softkappa"]:
                    ## softkappa with xgboost
                    obj = lambda preds, dtrain: softkappaObj(preds, dtrain, hess_scale=param['hess_scale'])
                    bst = xgb.train(param, dtrain_base, param['num_round'], watchlist, obj=obj,
                                    feval=evalerror_softkappa_valid)
                    pred = softmax(bst.predict(dvalid_base))
                    w = np.asarray(range(1, numOfClass + 1))
                    pred = pred * w[np.newaxis, :]
                    pred = np.sum(pred, axis=1)

                elif param["task"] in ["ebc"]:
                    ## ebc with xgboost
                    obj = lambda preds, dtrain: ebcObj(preds, dtrain)
                    bst = xgb.train(param, dtrain_base, param['num_round'], watchlist, obj=obj,
                                    feval=evalerror_ebc_valid)
                    pred = sigmoid(bst.predict(dvalid_base))
                    pred = applyEBCRule(pred, hard_threshold=ebc_hard_threshold)

                elif param["task"] in ["cocr"]:
                    ## cocr with xgboost
                    obj = lambda preds, dtrain: cocrObj(preds, dtrain)
                    bst = xgb.train(param, dtrain_base, param['num_round'], watchlist, obj=obj,
                                    feval=evalerror_cocr_valid)
                    pred = bst.predict(dvalid_base)
                    pred = applyCOCRRule(pred)

                elif param['task'] == "reg_skl_rf":
                    ## regression with sklearn random forest regressor
                    rf = RandomForestRegressor(n_estimators=param['n_estimators'],
                                               max_features=param['max_features'],
                                               n_jobs=param['n_jobs'],
                                               random_state=param['random_state'])
                    rf.fit(X_train.iloc[index_base], labels_train.iloc[index_base])
                    pred = rf.predict(X_valid)

                elif param['task'] == "reg_skl_etr":
                    ## regression with sklearn extra trees regressor
                    etr = ExtraTreesRegressor(n_estimators=param['n_estimators'],
                                              max_features=param['max_features'],
                                              n_jobs=param['n_jobs'],
                                              random_state=param['random_state'])
                    etr.fit(X_train.iloc[index_base], labels_train.iloc[index_base] )
                    pred = etr.predict(X_valid)

                elif param['task'] == "reg_skl_gbm":
                    ## regression with sklearn gradient boosting regressor
                    gbm = GradientBoostingRegressor(n_estimators=param['n_estimators'],
                                                    max_features=param['max_features'],
                                                    learning_rate=param['learning_rate'],
                                                    max_depth=param['max_depth'],
                                                    subsample=param['subsample'],
                                                    random_state=param['random_state'])
                    gbm.fit(X_train.iloc[index_base], labels_train.iloc[index_base] )
                    pred = gbm.predict(X_valid)

                elif param['task'] == "clf_skl_lr":
                    ## classification with sklearn logistic regression
                    lr = LogisticRegression(penalty="l2", dual=True, tol=1e-5,
                                            C=param['C'], fit_intercept=True, intercept_scaling=1.0,
                                            class_weight='auto', random_state=param['random_state'])
                    lr.fit(X_train.iloc[index_base], labels_train.iloc[index_base])
                    pred = lr.predict_proba(X_valid)
                    w = np.asarray(range(1, numOfClass + 1))
                    pred = pred * w[np.newaxis, :]
                    pred = np.sum(pred, axis=1)

                elif param['task'] == "reg_skl_svr":
                    ## regression with sklearn support vector regression
                    X_train, X_valid = X_train.values, X_valid.values
                    scaler = StandardScaler()
                    X_train[index_base] = scaler.fit_transform(X_train[index_base])
                    X_valid = scaler.transform(X_valid)
                    svr = SVR(C=param['C'], gamma=param['gamma'], epsilon=param['epsilon'],
                              degree=param['degree'], kernel=param['kernel'])
                    svr.fit(X_train[index_base], labels_train.iloc[index_base].values)
                    pred = svr.predict(X_valid)

                elif param['task'] == "reg_skl_ridge":
                    ## regression with sklearn ridge regression
                    ridge = Ridge(alpha=param["alpha"], normalize=True)
                    ridge.fit(X_train.iloc[index_base], labels_train.iloc[index_base])
                    pred = ridge.predict(X_valid)

                elif param['task'] == "reg_skl_lasso":
                    ## regression with sklearn lasso
                    lasso = Lasso(alpha=param["alpha"], normalize=True)
                    lasso.fit(X_train.iloc[index_base], labels_train.iloc[index_base])
                    pred = lasso.predict(X_valid)

                elif param['task'] == 'reg_libfm':
                    ## regression with factorization machine (libfm)
                    ## to array
                    X_train = X_train.toarray()
                    X_valid = X_valid.toarray()

                    ## scale
                    scaler = StandardScaler()
                    X_train[index_base] = scaler.fit_transform(X_train[index_base])
                    X_valid = scaler.transform(X_valid)

                    ## dump feat
                    dump_svmlight_file(X_train[index_base], labels_train[index_base], feat_train_path + ".tmp")
                    dump_svmlight_file(X_valid, labels_valid, feat_valid_path + ".tmp")

                    ## train fm
                    cmd = "%s -task r -train %s -test %s -out %s -dim '1,1,%d' -iter %d > libfm.log" % ( \
                        libfm_exe, feat_train_path + ".tmp", feat_valid_path + ".tmp", raw_pred_valid_path, \
                        param['dim'], param['iter'])
                    os.system(cmd)
                    os.remove(feat_train_path + ".tmp")
                    os.remove(feat_valid_path + ".tmp")

                    ## extract libfm prediction
                    pred = np.loadtxt(raw_pred_valid_path, dtype=float)
                    ## labels are in [0,1,2,3]
                    pred += 1

                elif param['task'] == "reg_keras_dnn":
                    ## regression with keras' deep neural networks
                    model = Sequential()
                    ## input layer
                    model.add(Dropout(param["input_dropout"], input_shape=(X_train.shape[1], )))
                    ## hidden layers
                    first = True
                    hidden_layers = param['hidden_layers']
                    while hidden_layers > 0:
                        if first:
                            dim = X_train.shape[1]
                            first = False
                        else:
                            dim = param["hidden_units"]
                        model.add(Dense(units=param["hidden_units"], kernel_initializer='glorot_uniform'))
                        if param["batch_norm"]:
                            model.add(BatchNormalization((param["hidden_units"],)))
                        if param["hidden_activation"] == "prelu":
                            model.add(PReLU((param["hidden_units"],)))
                        else:
                            model.add(Activation(param['hidden_activation']))
                        model.add(Dropout(param["hidden_dropout"]))
                        hidden_layers -= 1

                    ## output layer
                    model.add(Dense(units=1, kernel_initializer='glorot_uniform'))
                    model.add(Activation('linear'))

                    ## loss
                    model.compile(loss='mean_squared_error', optimizer='adam')

                    ## to array
                    X_train = X_train.values
                    X_valid = X_valid.values

                    ## scale
                    scaler = StandardScaler()
                    X_train[index_base] = scaler.fit_transform(X_train[index_base])
                    X_valid = scaler.transform(X_valid)

                    ## train
                    model.fit(X_train[index_base], labels_train.iloc[index_base].values,
                              nb_epoch=param['nb_epoch'], batch_size=param['batch_size'],
                              validation_split=0, verbose=0)

                    ##prediction
                    pred = model.predict(X_valid, verbose=0)
                    pred.shape = (X_valid.shape[0],)

                elif param['task'] == 'reg_pytorch_dnn':
                    with open(config.processed_train_trans_path, "rb") as f:
                        trans = cPickle.load(f)
                    X_train = X_train.values
                    X_valid = X_valid.values
                    Y_train = labels_train.values
                    net = DNN_Net(X_train, Y_train, X_train.shape[1], param, [100,64,64,32])
                    print net
                    optimizer = torch.optim.SGD(net.parameters(), lr=0.01)
                    loss_func = torch.nn.MSELoss()
                    plt.ion()
                    loss_raw=[]

                    for i in range(0, 1000, 1):
                        print i
                        datalist = net.get_dataloader()
                        for x, y in datalist:
                            x = Variable(torch.FloatTensor(x))
                            y = Variable(torch.FloatTensor(y))
                            #x, y = x.cuda(), y.cuda()
                            pred = net(x)
                            loss = loss_func(pred, y)
                            # Clear grads
                            optimizer.zero_grad()
                            # backward
                            loss.backward()
                            # Update
                            optimizer.step()

                            y_raw = y.data.numpy() * trans['L'] + trans['v']
                            pred_raw = pred.data.numpy() * trans['L'] + trans['v']
                            loss_raw.append( np.sum(np.power(y_raw - pred_raw, 2))/len(y))
                            plt.close()
                            plt.plot(range(0, len(loss_raw), 1), loss_raw)
                            plt.pause(1)



                elif param['task'] == "reg_rgf":
                    ## regression with regularized greedy forest (rgf)
                    ## to array
                    X_train, X_valid = X_train.toarray(), X_valid.toarray()

                    train_x_fn = feat_train_path + ".x"
                    train_y_fn = feat_train_path + ".y"
                    valid_x_fn = feat_valid_path + ".x"
                    valid_pred_fn = feat_valid_path + ".pred"

                    model_fn_prefix = "rgf_model"

                    np.savetxt(train_x_fn, X_train[index_base], fmt="%.6f", delimiter='\t')
                    np.savetxt(train_y_fn, labels_train[index_base], fmt="%d", delimiter='\t')
                    np.savetxt(valid_x_fn, X_valid, fmt="%.6f", delimiter='\t')
                    # np.savetxt(valid_y_fn, labels_valid, fmt="%d", delimiter='\t')


                    pars = [
                        "train_x_fn=", train_x_fn, "\n",
                        "train_y_fn=", train_y_fn, "\n",
                        # "train_w_fn=",weight_train_path,"\n",
                        "model_fn_prefix=", model_fn_prefix, "\n",
                        "reg_L2=", param['reg_L2'], "\n",
                        # "reg_depth=", 1.01, "\n",
                        "algorithm=", "RGF", "\n",
                        "loss=", "LS", "\n",
                        # "opt_interval=", 100, "\n",
                        "valid_interval=", param['max_leaf_forest'], "\n",
                        "max_leaf_forest=", param['max_leaf_forest'], "\n",
                        "num_iteration_opt=", param['num_iteration_opt'], "\n",
                        "num_tree_search=", param['num_tree_search'], "\n",
                        "min_pop=", param['min_pop'], "\n",
                        "opt_interval=", param['opt_interval'], "\n",
                        "opt_stepsize=", param['opt_stepsize'], "\n",
                        "NormalizeTarget"
                    ]
                    pars = "".join([str(p) for p in pars])

                    rfg_setting_train = "./rfg_setting_train"
                    with open(rfg_setting_train + ".inp", "wb") as f:
                        f.write(pars)

                    ## train fm
                    cmd = "perl %s %s train %s >> rgf.log" % (
                        call_exe, rgf_exe, rfg_setting_train)
                    # print cmd
                    os.system(cmd)

                    model_fn = model_fn_prefix + "-01"
                    pars = [
                        "test_x_fn=", valid_x_fn, "\n",
                        "model_fn=", model_fn, "\n",
                        "prediction_fn=", valid_pred_fn
                    ]

                    pars = "".join([str(p) for p in pars])

                    rfg_setting_valid = "./rfg_setting_valid"
                    with open(rfg_setting_valid + ".inp", "wb") as f:
                        f.write(pars)
                    cmd = "perl %s %s predict %s >> rgf.log" % (
                        call_exe, rgf_exe, rfg_setting_valid)
                    # print cmd
                    os.system(cmd)

                    pred = np.loadtxt(valid_pred_fn, dtype=float)

                ## weighted averageing over different models
                pred_valid = pred
                ## this bagging iteration
                preds_bagging[:, n] = pred_valid
                pred_raw = np.mean(preds_bagging[:, :(n + 1)], axis=1)
                pred_rank = pred_raw.argsort().argsort()

                with open(config.processed_train_trans_path, "rb") as f:
                    trans = cPickle.load(f)
                pred_raw = pred_raw * trans['L'] + trans['v']
                labels_valid_trans = labels_valid.values * trans['L'] + trans['v']
                kappa_valid = np.sum(np.power(labels_valid_trans - pred_raw, 2))/numValid

                if (n + 1) != bagging_size:
                    print("              {:>3}   {:>3}   {:>3}   {:>6}   {} x {}".format(
                        run, fold, n + 1, np.round(kappa_valid, 6), X_train.shape[0], X_train.shape[1]))
                else:
                    print("                    {:>3}       {:>3}      {:>3}    {:>8}  {} x {}".format(
                        run, fold, n + 1, np.round(kappa_valid, 6), X_train.shape[0], X_train.shape[1]))
            kappa_cv[run - 1, fold - 1] = kappa_valid
            ## save this prediction
            dfPred = pd.DataFrame({"target": labels_valid_trans, "prediction": pred_raw})
            dfPred.to_csv(raw_pred_valid_path, index=False, header=True,
                          columns=["target", "prediction"])
            ## save this prediction
            dfPred = pd.DataFrame({"target": labels_valid_trans, "prediction": pred_rank})
            dfPred.to_csv(rank_pred_valid_path, index=False, header=True,
                          columns=["target", "prediction"])

    kappa_cv_mean = np.mean(kappa_cv)
    kappa_cv_std = np.std(kappa_cv)
    if verbose_level >= 1:
        print("              Mean: %.6f" % kappa_cv_mean)
        print("              Std: %.6f" % kappa_cv_std)

    ####################
    #### Retraining ####
    ####################
    #### all the path
    path = "%s/All" % (feat_folder)
    save_path = "%s/All" % output_path
    subm_path = "%s/Subm" % output_path
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    if not os.path.exists(subm_path):
        os.makedirs(subm_path)
    # feat
    feat_train_path = "%s/train.feat.pkl" % path
    feat_test_path = "%s/test.feat.pkl" % path
    # raw prediction path (rank)
    raw_pred_test_path = "%s/test.raw.pred.%s_[Id@%d].csv" % (save_path, feat_name, trial_counter)
    rank_pred_test_path = "%s/test.pred.%s_[Id@%d].csv" % (save_path, feat_name, trial_counter)
    # submission path (relevance as in [1,2,3,4])
    subm_path = "%s/test.pred.%s_[Id@%d]_[Mean%.6f]_[Std%.6f].csv" % (
    subm_path, feat_name, trial_counter, kappa_cv_mean, kappa_cv_std)

    #### load data
    ## load feat
    with open(feat_train_path, "rb") as f:
        X_train = cPickle.load(f)
    with open(feat_test_path, "rb") as f:
        X_test = cPickle.load(f)
    numTrain, numTest = X_train.shape[0], X_test.shape[0]
    num_feats = X_test.shape[1] - 1
    labels_test = X_test['Y']
    X_test = X_test[X_test.keys()[:num_feats]]
    labels_train = X_train['Y']
    X_train = X_train[X_train.keys()[:num_feats]]

    ## bagging
    preds_bagging = np.zeros((numTest, bagging_size), dtype=float)
    for n in range(bagging_size):
        if bootstrap_replacement:
            sampleSize = int(numTrain * bootstrap_ratio)
            # index_meta = rng.randint(numTrain, size=sampleSize)
            # index_base = [i for i in range(numTrain) if i not in index_meta]
            index_base = rng.randint(numTrain, size=sampleSize)
            index_meta = [i for i in range(numTrain) if i not in index_base]
        else:
            randnum = rng.uniform(size=numTrain)
            index_base = [i for i in range(numTrain) if randnum[i] < bootstrap_ratio]
            index_meta = [i for i in range(numTrain) if randnum[i] >= bootstrap_ratio]

        if param.has_key("booster"):
            dtest = xgb.DMatrix(X_test, label=labels_test)
            dtrain = xgb.DMatrix(X_train.iloc[index_base], label=labels_train.iloc[index_base])

            watchlist = []
            if verbose_level >= 2:
                watchlist = [(dtrain, 'train')]

        ## train
        if param["task"] in ["regression", "ranking"]:
            bst = xgb.train(param, dtrain, param['num_round'], watchlist, feval='rmse')
            pred = bst.predict(dtest)

        elif param["task"] in ["softmax"]:
            bst = xgb.train(param, dtrain, param['num_round'], watchlist, feval=evalerror_softmax_test)
            pred = bst.predict(dtest)
            w = np.asarray(range(1, numOfClass + 1))
            pred = pred * w[np.newaxis, :]
            pred = np.sum(pred, axis=1)

        elif param["task"] in ["softkappa"]:
            obj = lambda preds, dtrain: softkappaObj(preds, dtrain, hess_scale=param['hess_scale'])
            bst = xgb.train(param, dtrain, param['num_round'], watchlist, obj=obj, feval=evalerror_softkappa_test)
            pred = softmax(bst.predict(dtest))
            w = np.asarray(range(1, numOfClass + 1))
            pred = pred * w[np.newaxis, :]
            pred = np.sum(pred, axis=1)

        elif param["task"] in ["ebc"]:
            obj = lambda preds, dtrain: ebcObj(preds, dtrain)
            bst = xgb.train(param, dtrain, param['num_round'], watchlist, obj=obj, feval=evalerror_ebc_test)
            pred = sigmoid(bst.predict(dtest))
            pred = applyEBCRule(pred, hard_threshold=ebc_hard_threshold)

        elif param["task"] in ["cocr"]:
            obj = lambda preds, dtrain: cocrObj(preds, dtrain)
            bst = xgb.train(param, dtrain, param['num_round'], watchlist, obj=obj, feval=evalerror_cocr_test)
            pred = bst.predict(dtest)
            pred = applyCOCRRule(pred)

        elif param['task'] == "reg_skl_rf":
            ## random forest regressor
            rf = RandomForestRegressor(n_estimators=param['n_estimators'],
                                       max_features=param['max_features'],
                                       n_jobs=param['n_jobs'],
                                       random_state=param['random_state'])
            rf.fit(X_train.iloc[index_base], labels_train.iloc[index_base])
            pred = rf.predict(X_test)

        elif param['task'] == "reg_skl_etr":
            ## extra trees regressor
            etr = ExtraTreesRegressor(n_estimators=param['n_estimators'],
                                      max_features=param['max_features'],
                                      n_jobs=param['n_jobs'],
                                      random_state=param['random_state'])
            etr.fit(X_train.iloc[index_base], labels_train.iloc[index_base])
            pred = etr.predict(X_test)

        elif param['task'] == "reg_skl_gbm":
            ## gradient boosting regressor
            gbm = GradientBoostingRegressor(n_estimators=param['n_estimators'],
                                            max_features=param['max_features'],
                                            learning_rate=param['learning_rate'],
                                            max_depth=param['max_depth'],
                                            subsample=param['subsample'],
                                            random_state=param['random_state'])
            gbm.fit(X_train.iloc[index_base], labels_train.iloc[index_base])
            pred = gbm.predict(X_test)

        elif param['task'] == "clf_skl_lr":
            lr = LogisticRegression(penalty="l2", dual=True, tol=1e-5,
                                    C=param['C'], fit_intercept=True, intercept_scaling=1.0,
                                    class_weight='auto', random_state=param['random_state'])
            lr.fit(X_train.iloc[index_base], labels_train.iloc[index_base])
            pred = lr.predict_proba(X_test)
            w = np.asarray(range(1, numOfClass + 1))
            pred = pred * w[np.newaxis, :]
            pred = np.sum(pred, axis=1)

        elif param['task'] == "reg_skl_svr":
            ## regression with sklearn support vector regression
            X_train, X_test = X_train.values, X_test.values
            scaler = StandardScaler()
            X_train[index_base] = scaler.fit_transform(X_train[index_base])
            X_test = scaler.transform(X_test)
            svr = SVR(C=param['C'], gamma=param['gamma'], epsilon=param['epsilon'],
                      degree=param['degree'], kernel=param['kernel'])
            svr.fit(X_train[index_base], labels_train.iloc[index_base].values)
            pred = svr.predict(X_test)

        elif param['task'] == "reg_skl_ridge":
            ridge = Ridge(alpha=param["alpha"], normalize=True)
            ridge.fit(X_train.iloc[index_base], labels_train.iloc[index_base])
            pred = ridge.predict(X_test)

        elif param['task'] == "reg_skl_lasso":
            lasso = Lasso(alpha=param["alpha"], normalize=True)
            lasso.fit(X_train.iloc[index_base], labels_train.iloc[index_base])
            pred = lasso.predict(X_test)

        elif param['task'] == 'reg_libfm':
            ## to array
            X_train, X_test = X_train.toarray(), X_test.toarray()

            ## scale
            scaler = StandardScaler()
            X_train[index_base] = scaler.fit_transform(X_train[index_base])
            X_test = scaler.transform(X_test)

            ## dump feat
            dump_svmlight_file(X_train[index_base], labels_train[index_base], feat_train_path + ".tmp")
            dump_svmlight_file(X_test, labels_test, feat_test_path + ".tmp")

            ## train fm
            cmd = "%s -task r -train %s -test %s -out %s -dim '1,1,%d' -iter %d > libfm.log" % ( \
                libfm_exe, feat_train_path + ".tmp", feat_test_path + ".tmp", raw_pred_test_path, \
                param['dim'], param['iter'])
            os.system(cmd)
            os.remove(feat_train_path + ".tmp")
            os.remove(feat_test_path + ".tmp")

            ## extract libfm prediction
            pred = np.loadtxt(raw_pred_test_path, dtype=float)
            ## labels are in [0,1,2,3]
            pred += 1

        elif param['task'] == "reg_keras_dnn":
            ## regression with keras deep neural networks
            model = Sequential()
            ## input layer
            model.add(Dropout(param["input_dropout"]))
            ## hidden layers
            first = True
            hidden_layers = param['hidden_layers']
            while hidden_layers > 0:
                if first:
                    dim = X_train.shape[1]
                    first = False
                else:
                    dim = param["hidden_units"]
                model.add(Dense(dim, param["hidden_units"], init='glorot_uniform'))
                if param["batch_norm"]:
                    model.add(BatchNormalization((param["hidden_units"],)))
                if param["hidden_activation"] == "prelu":
                    model.add(PReLU((param["hidden_units"],)))
                else:
                    model.add(Activation(param['hidden_activation']))
                model.add(Dropout(param["hidden_dropout"]))
                hidden_layers -= 1

            ## output layer
            model.add(Dense(param["hidden_units"], 1, init='glorot_uniform'))
            model.add(Activation('linear'))

            ## loss
            model.compile(loss='mean_squared_error', optimizer="adam")

            ## to array
            X_train = X_train.values
            X_test = X_test.values

            ## scale
            scaler = StandardScaler()
            X_train[index_base] = scaler.fit_transform(X_train[index_base])
            X_test = scaler.transform(X_test)

            ## train
            model.fit(X_train[index_base], labels_train.iloc[index_base].values,
                      nb_epoch=param['nb_epoch'], batch_size=param['batch_size'], verbose=0)

            ##prediction
            pred = model.predict(X_test, verbose=0)
            pred.shape = (X_test.shape[0],)

        elif param['task'] == "reg_rgf":
            ## to array
            X_train, X_test = X_train.toarray(), X_test.toarray()

            train_x_fn = feat_train_path + ".x"
            train_y_fn = feat_train_path + ".y"
            test_x_fn = feat_test_path + ".x"
            test_pred_fn = feat_test_path + ".pred"

            model_fn_prefix = "rgf_model"

            np.savetxt(train_x_fn, X_train[index_base], fmt="%.6f", delimiter='\t')
            np.savetxt(train_y_fn, labels_train[index_base], fmt="%d", delimiter='\t')
            np.savetxt(test_x_fn, X_test, fmt="%.6f", delimiter='\t')
            # np.savetxt(valid_y_fn, labels_valid, fmt="%d", delimiter='\t')


            pars = [
                "train_x_fn=", train_x_fn, "\n",
                "train_y_fn=", train_y_fn, "\n",
                # "train_w_fn=",weight_train_path,"\n",
                "model_fn_prefix=", model_fn_prefix, "\n",
                "reg_L2=", param['reg_L2'], "\n",
                # "reg_depth=", 1.01, "\n",
                "algorithm=", "RGF", "\n",
                "loss=", "LS", "\n",
                "test_interval=", param['max_leaf_forest'], "\n",
                "max_leaf_forest=", param['max_leaf_forest'], "\n",
                "num_iteration_opt=", param['num_iteration_opt'], "\n",
                "num_tree_search=", param['num_tree_search'], "\n",
                "min_pop=", param['min_pop'], "\n",
                "opt_interval=", param['opt_interval'], "\n",
                "opt_stepsize=", param['opt_stepsize'], "\n",
                "NormalizeTarget"
            ]
            pars = "".join([str(p) for p in pars])

            rfg_setting_train = "./rfg_setting_train"
            with open(rfg_setting_train + ".inp", "wb") as f:
                f.write(pars)

            ## train fm
            cmd = "perl %s %s train %s >> rgf.log" % (
                call_exe, rgf_exe, rfg_setting_train)
            # print cmd
            os.system(cmd)

            model_fn = model_fn_prefix + "-01"
            pars = [
                "test_x_fn=", test_x_fn, "\n",
                "model_fn=", model_fn, "\n",
                "prediction_fn=", test_pred_fn
            ]

            pars = "".join([str(p) for p in pars])

            rfg_setting_test = "./rfg_setting_test"
            with open(rfg_setting_test + ".inp", "wb") as f:
                f.write(pars)
            cmd = "perl %s %s predict %s >> rgf.log" % (
                call_exe, rgf_exe, rfg_setting_test)
            # print cmd
            os.system(cmd)

            pred = np.loadtxt(test_pred_fn, dtype=float)

        ## weighted averageing over different models
        pred_test = pred
        preds_bagging[:, n] = pred_test
    pred_raw = np.mean(preds_bagging, axis=1)
    with open(config.processed_train_trans_path, "rb") as f:
        trans = cPickle.load(f)
    with open(config.processed_train_data_path, "rb") as f:
        id_test = cPickle.load(f).loc[500:, 'ID']
    id_test = id_test.values
    pred_raw = pred_raw * trans['L'] + trans['v']
    pred_rank = pred_raw.argsort().argsort()
    #
    ## write
    output = pd.DataFrame({"ID": id_test, "prediction": pred_raw})
    output.to_csv(raw_pred_test_path, index=False)

    ## write
    output = pd.DataFrame({"ID": id_test, "prediction": pred_rank})
    output.to_csv(rank_pred_test_path, index=False)

    return kappa_cv_mean, kappa_cv_std


####################
## Model Buliding ##
####################

def check_model(models, feat_name):
    if models == "all":
        return True
    for model in models:
        if model in feat_name:
            return True
    return False


if __name__ == "__main__":

    specified_models = []
    #specified_models.append('reg_pytorch_dnn')
    #specified_models.append('reg_skl_lasso')
    # Ridge is not good.
    #specified_models.append('reg_skl_ridge')
    #specified_models.append('reg_skl_svr')
    #specified_models.append('reg_skl_gbm')
    #specified_models.append('reg_skl_etr')
    #specified_models.append('reg_skl_rf')
    #specified_models.append('reg_xgb_linear')
    specified_models.append('reg_xgb_tree')
    if len(specified_models) == 0:
        print("You have to specify which model to train.\n")
        print("Usage: python ./train_model_library_lsa.py model1 model2 model3 ...\n")
        print("Example: python ./train_model_library_lsa.py reg_skl_ridge reg_skl_lasso reg_skl_svr\n")
        print("See model_library_config_lsa.py for a list of available models (i.e., Model@model_name)")
        sys.exit()
    log_path = "%s/Log" % output_path
    if not os.path.exists(log_path):
        os.makedirs(log_path)
    for feat_name, feat_folder in zip(feat_names, feat_folders):
        if not check_model(specified_models, feat_name):
            continue
        param_space = param_spaces[feat_name]
        # """

        log_file = "%s/%s_hyperopt.log" % (log_path, feat_name)
        log_handler = open(log_file, 'wb')
        writer = csv.writer(log_handler)
        headers = ['trial_counter', 'kappa_mean', 'kappa_std']
        for k, v in sorted(param_space.items()):
            headers.append(k)
        writer.writerow(headers)
        log_handler.flush()

        print("************************************************************")
        print("Search for the best params")
        # global trial_counter
        trial_counter = 0
        trials = Trials()
        objective = lambda p: hyperopt_wrapper(p, feat_folder, feat_name)
        best_params = fmin(objective, param_space, algo=tpe.suggest,
                           trials=trials, max_evals=param_space["max_evals"])
        for f in int_feat:
            if best_params.has_key(f):
                best_params[f] = int(best_params[f])
        print("************************************************************")
        print("Best params")
        for k, v in best_params.items():
            print "        %s: %s" % (k, v)
        trial_kappas = -np.asarray(trials.losses(), dtype=float)
        best_kappa_mean = min(trial_kappas)
        ind = np.where(trial_kappas == best_kappa_mean)[0][0]
        best_kappa_std = trials.trial_attachments(trials.trials[ind])['std']
        print("Kappa stats")
        print("        Mean: %.6f\n        Std: %.6f" % (best_kappa_mean, best_kappa_std))