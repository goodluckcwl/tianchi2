import xgboost as xgb
import scipy.io as sio
import numpy as np
import os
import csv
import pandas as pd


def gen_cross_validation_data(X, Y, n_cv):
    n_samples, n_feats = X.shape
    n_val = n_samples/n_cv
    n_tr = n_samples - n_val
    X_tr_list = []
    Y_tr_list = []
    X_val_list = []
    Y_val_list = []
    I = np.linspace(0, n_samples - 1, n_samples, dtype='int').tolist()
    np.random.shuffle(I)
    for i in range(0, n_cv):
        idx_val = I[i*n_val:n_val + i*n_val]
        idx_tr = np.copy(I).tolist();
        idx_tr[i*n_val:n_val + i*n_val] = []
        X_tr = X[idx_tr, :]
        X_tr_list.append(X_tr)
        Y_tr = Y[idx_tr]
        Y_tr_list.append(Y_tr)
        X_val = X[idx_val, :]
        X_val_list.append(X_val)
        Y_val = Y[idx_val]
        Y_val_list.append(Y_val)
    return X_tr_list, Y_tr_list, X_val_list, Y_val_list

def apply_transform(Y, T):
    Y = Y * T['L'][0,0][0,0] + T['v'][0,0][0,0]
    return Y

def write_csv_file(infile,outfile, Y):
    reader = csv.reader(file(infile, 'r'))
    ids = []
    for line in reader:
        ids.append(line[0])

    writer = csv.writer(file(outfile, 'w'))
    for i in range(len(ids)):
        line = []
        line.append(ids[i])
        line.append(str(Y[i]))
        writer.writerow(line)

def ensemble_csv_file(infile_list, outfile):
    Ys = []
    for infile in infile_list:
        reader = csv.reader(file(infile, 'r'))
        ids = []
        Y = []
        for line in reader:
            ids.append(line[0])
            Y.append(line[1])
        Ys.append(Y)
    Y_m = np.zeros([len(Ys[0]), 1])
    for Y in Ys:
        Y_m = Y_m + np.array(Y, dtype='float').reshape([100, 1])
    Y_m = Y_m / len(Ys)

    writer = csv.writer(file(outfile, 'w'))
    for i in range(len(ids)):
        line = []
        line.append(ids[i])
        line.append(str(Y_m[i][0]))
        writer.writerow(line)





data_dir = '../dataset/traindata.mat'
data = sio.loadmat(data_dir)
X = data['train']['X'][0][0]
Y = data['train']['Y'][0][0]
X_ab = data['test']['X'][0][0]
T = data['train']['T'][0][0]
n_samples, n_feats = X.shape

#csv_list = ['testA.csv','../NN-Caffe/testA.csv']
#ensemble_csv_file(csv_list, 'testA_ensemble.csv')

#
model_path = 'xgboost-model'
if not os.path.exists(model_path):
    os.mkdir(model_path)

# 5-folder cross validation
n_cv = 5
X_tr_list, Y_tr_list, X_val_list, Y_val_list = gen_cross_validation_data(X, Y, n_cv)
mse = np.zeros([n_cv, 1])
gbtree_list = []
for i in range(n_cv):
    print 'Round {}'.format(i)
    X_tr, Y_tr = X_tr_list[i], Y_tr_list[i]
    X_val, Y_val = X_val_list[i], Y_val_list[i]


    gbtree = xgb.XGBRegressor(max_depth=10,
                             learning_rate=0.1,
                             n_estimators=1000,
                             silent=True,
                             objective='reg:linear',
                             booster='gbtree',
                             n_jobs=1,
                             gamma=0,
                             min_child_weight=20,
                             max_delta_step=0,
                             subsample=0.5,
                             colsample_bytree=0.5,
                             #colsample_bylevel=0.5,
                             # L1
                             reg_alpha=1,
                             # L2
                             reg_lambda=1,
                             scale_pos_weight=1,
                             base_score=0.5,
                             seed=44343)

    gbtree.fit(X_tr, Y_tr, eval_set=[(X_val, Y_val)], eval_metric='rmse', early_stopping_rounds=100)
    preds = apply_transform(gbtree.predict(X_val), T)
    Y_val = apply_transform(Y_val, T)
    preds = preds.reshape( [len(Y_val), 1])
    mse[i] = np.sum(np.power(Y_val - preds, 2))/len(Y_val)
    # Save model
    gbtree_list.append(gbtree)
    #gbtree.save_model(os.path.join(model_path, '{}.bin'.format(i)))

Y_ab = np.zeros([X_ab.shape[0], n_cv])
for i in range(n_cv):
    gbtree = gbtree_list[i]
    Y_ab[:, i] = apply_transform(gbtree.predict(X_ab), T)

Y_ab_en = np.mean(Y_ab, 1)

write_csv_file('../Data/testA-muban.csv','testA.csv',Y_ab_en[0:100])


for i in range(n_cv):
    print 'mse: {}'.format(mse[i])
print 'mean-mse: {}'.format(np.mean(mse))









