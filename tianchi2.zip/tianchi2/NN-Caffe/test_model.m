clc;clear all;

load('python/Y_tr_pred.mat');
load('python/Y_test.mat');
load('../dataset/traindata.mat');

T = train.T;
Y_tr = Y_tr_pred * T.L + T.v;
Y_gt = train.Y * T.L + T.v;

mse = sum((Y_tr - Y_gt).^2)/length(Y_gt);

Y_pred = Y_test * T.L + T.v;
Y_a = Y_pred(1:100);

save Y_testA.mat Y_a