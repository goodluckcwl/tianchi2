function [ blob ] = data_list_to_blob( dlist )
   num = length(dlist);
   shape =size(dlist{1});
   blob = zeros(shape(2), 1, 1, num, 'single');
    
    for i = 1:length(dlist)
        data = dlist{i};
        blob(:, :, :, i) = data(:); 
    end


end

