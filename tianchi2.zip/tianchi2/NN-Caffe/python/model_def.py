# -*- coding: utf-8 -*-
# @Author: chenweiliang
# @Date:   2018-01-05 14:33:36
# @Last Modified by:   chenweiliang
# @Last Modified time: 2018-01-05 15:51:44

import sys
sys.path.insert(0, '/home/chenweiliang/caffe-windows-ms/python')
import caffe
from caffe import layers as L, params as P
import numpy as np
import scipy.io as sio

def max_pool(bottom, ks=2, stride=2):
    return L.Pooling(bottom, pool=P.Pooling.MAX, kernel_size=ks, stride=stride)

def ip(bottom, num_output):
    fc = L.InnerProduct(bottom, param=[dict(lr_mult=1), dict(lr_mult=2)],
         inner_product_param=dict(num_output=num_output, weight_filler=dict(type='xavier'),
         bias_filler=dict(type='constant')))
    return fc

def ip_relu(bottom, num_output):
    fc = L.InnerProduct(bottom, param=[dict(lr_mult=1), dict(lr_mult=2)],
        inner_product_param=dict(num_output=num_output, weight_filler=dict(type='xavier'),
           bias_filler=dict(type='constant')))
    return fc, L.ReLU(fc, in_place=True)

def ip_prelu(bottom, num_output):
    fc = L.InnerProduct(bottom, param=[dict(lr_mult=1), dict(lr_mult=2)],
        inner_product_param=dict(num_output=num_output, weight_filler=dict(type='xavier'),
            bias_filler=dict(type='constant')))
    return fc, L.PReLU(fc, in_place=True)

def conv_relu(bottom, nout, ks=3, stride=1, pad=1):
    conv = L.Convolution(bottom,
                         convolution_param=dict(num_output=nout,
                                                kernel_size=ks,
                                                stride=stride,pad=pad,
                                                weight_filler=dict(type='xavier'),
                                                bias_filler=dict(type='constant',value=0)
                                                ),
                         param=[dict(lr_mult=1, decay_mult=1), dict(lr_mult=2, decay_mult=0)]
                         )
    return conv, L.ReLU(conv, in_place=True)

def deconv_relu(bottom, nout, ks=2, stride=2, pad=0):
    conv = L.Deconvolution(bottom,
                           convolution_param=dict(num_output=nout,
                                                  kernel_size=ks,
                                                  stride=stride,pad=pad,
                                                  weight_filler=dict(type='xavier'),
                                                  bias_filler=dict(type='constant', value=0)
                                                  ),
                           param=[dict(lr_mult=1, decay_mult=1), dict(lr_mult=2, decay_mult=0)]
                           )
    return conv, L.ReLU(conv, in_place=True)



def dnn_prelu(split):
    n = caffe.NetSpec()
    pydata_params = dict(split=split, mean=(127.5,127.5,127.5), scale=0.0078125, seed=1337, batch_size=64)
    pylayer='FaceDataLayer'
    if split=='train':
        pydata_params['root_dir'] = 'train-fcn-112_112-stage1-testing'
        pydata_params['file_dir'] = 'train-fcn-112_112-stage1-testing/fcn_stage1.mat'
    else:
        pydata_params['root_dir'] = '300W'

    if split=='train':
        #n.data, n.label = L.Python(module='lm_layers', layer=pylayer,
        #                       ntop=2, param_str=str(pydata_params))
        n.x,n.y = L.HDF5Data(include=dict(phase=caffe.TRAIN),
                          hdf5_data_param=dict(source='hdf5/train.txt',
                                                batch_size= 32), ntop=2)
        n.x1, n.y1 = L.HDF5Data(include=dict(phase=caffe.TEST),
                  hdf5_data_param=dict(source='hdf5/val.txt',
                                        batch_size= 32), ntop=2)
    else:
        n.x = L.Input(input_param=dict(
            shape=dict(dim=[1,1,1,1])
        ))

    # the base net
    n.drop_x = L.Dropout(n.x, in_place=True, dropout_param=dict(dropout_ratio=0.5))
    n.fc1, n.relu1 = ip_prelu(n.drop_x, 100)
    n.drop1 = L.Dropout(n.relu1, in_place=True, dropout_param=dict(dropout_ratio=0.4))
    n.fc2, n.relu2 = ip_prelu(n.drop1, 100)
    n.drop2 = L.Dropout(n.relu2, in_place=True, dropout_param=dict(dropout_ratio=0.3))
    n.fc3, n.relu3 = ip_prelu(n.drop2, 10)
    n.drop3 = L.Dropout(n.relu3, in_place=True, dropout_param=dict(dropout_ratio=0.3))
    n.fc4, n.relu4 = ip_prelu(n.drop3, 10)
    n.drop4= L.Dropout(n.relu4, in_place=True, dropout_param=dict(dropout_ratio=0.3))

    n.pred = ip(n.relu4, 1)

    if split=='train':
        n.loss = L.EuclideanLoss(n.pred, n.y, include=dict(phase=caffe.TRAIN))
        n.error = L.EuclideanLoss(n.pred, n.y, include=dict(phase=caffe.TEST))
    else:
        pass

    return n.to_proto()

def cnn_dnn(split):
    n = caffe.NetSpec()
    pydata_params = dict(split=split, mean=(127.5,127.5,127.5), scale=0.0078125, seed=1337, batch_size=64)
    pylayer='FaceDataLayer'
    if split=='train':
        pydata_params['root_dir'] = 'train-fcn-112_112-stage1-testing'
        pydata_params['file_dir'] = 'train-fcn-112_112-stage1-testing/fcn_stage1.mat'
    else:
        pydata_params['root_dir'] = '300W'

    if split=='train':
        #n.data, n.label = L.Python(module='lm_layers', layer=pylayer,
        #                       ntop=2, param_str=str(pydata_params))
        n.x,n.y = L.HDF5Data(include=dict(phase=caffe.TRAIN),
                          hdf5_data_param=dict(source='hdf5/train.txt',
                                                batch_size= 32), ntop=2)
        n.x1, n.y1 = L.HDF5Data(include=dict(phase=caffe.TEST),
                  hdf5_data_param=dict(source='hdf5/val.txt',
                                        batch_size= 32), ntop=2)
    else:
        n.x = L.Input(input_param=dict(
            shape=dict(dim=[1,1,1,1])
        ))

    # the base net
    n.conv1, n.relu1 = conv_relu(n.x, nout=4, ks=1, stride=1)
    n.pool1 = max_pool(n.relu1)
    n.conv2, n.relu2 = conv_relu(n.pool1, nout=4, ks=1, stride=1)
    n.pool2 = max_pool(n.relu2)
    n.conv3, n.relu3 = conv_relu(n.pool2, nout=8, ks=1, stride=1)
    n.pool3 = max_pool(n.relu3)
    n.pool3 = L.Dropout(n.pool3, in_place=True, dropout_param=dict(dropout_ratio=0.4))
    n.fc1, n.fc1_relu = ip_relu(n.pool3, num_output=100)
    n.fc1_relu = L.Dropout(n.fc1_relu, in_place=True, dropout_param=dict(dropout_ratio=0.4))

    n.pred = ip(n.fc1_relu, 1)

    if split=='train':
        n.loss = L.EuclideanLoss(n.pred, n.y, include=dict(phase=caffe.TRAIN))
        n.error = L.EuclideanLoss(n.pred, n.y, include=dict(phase=caffe.TEST))
    else:
        pass
    return n.to_proto()

def fcn(split):
    n = caffe.NetSpec()
    pydata_params = dict(split=split, mean=(127.5,127.5,127.5), scale=0.0078125, seed=1337, batch_size=64)
    pylayer='FaceDataLayer'
    if split=='train':
        pydata_params['root_dir'] = 'train-fcn-112_112-stage1-testing'
        pydata_params['file_dir'] = 'train-fcn-112_112-stage1-testing/fcn_stage1.mat'
    else:
        pydata_params['root_dir'] = '300W'

    if split=='train':
        n.data, n.label = L.Python(module='lm_layers', layer=pylayer,
                               ntop=2, param_str=str(pydata_params))
        # n.data,n.label = L.ImageData(include=dict(phase=caffe.TRAIN),
        #                  transform_param=dict(mean_value=127.5,
        #                                       scale=0.0078125,
        #                                       mirror=False),
        #                  image_data_param=dict(source='',
        #                                        root_folder='',
        #                                        batch_size= 64,
        #                                    shuffle=True), ntop=2)
    else:
        n.data = L.Input(input_param=dict(
            shape=dict(dim=[1,3,112,112])
        ))

    # the base net
    n.conv1_1, n.relu1_1 = conv_relu(n.data, 64)
    n.conv1_2, n.relu1_2 = conv_relu(n.relu1_1, 64)
    n.pool1 = max_pool(n.relu1_2)

    n.conv2_1, n.relu2_1 = conv_relu(n.pool1, 128)
    n.conv2_2, n.relu2_2 = conv_relu(n.relu2_1, 128)
    n.pool2 = max_pool(n.relu2_2)

    n.conv3_1, n.relu3_1 = conv_relu(n.pool2, 256)
    n.conv3_2, n.relu3_2 = conv_relu(n.relu3_1, 256)
    n.pool3 = max_pool(n.relu3_2)

    n.conv4_1, n.relu4_1 = conv_relu(n.pool3, 512)
    n.conv4_2, n.relu4_2 = conv_relu(n.relu4_1, 512)
    n.pool4 = max_pool(n.relu4_2)

    # fully conv
    n.upconv1, n.uprelu1 = deconv_relu(n.pool4, 512)
    n.concate1 = L.Concate(n.uprelu1, n.relu4_2, concat_param=dict(axis=1))
    n.conv5, n.relu5 = conv_relu(n.concate1, 256)

    n.upconv2, n.uprelu2 = deconv_relu(n.relu5, 256)
    n.concate2 = L.Concate(n.uprelu2, n.relu3_2, concat_param=dict(axis=1))
    n.conv6, n.relu6 = conv_relu(n.concate2, 128)

    n.upconv3, n.uprelu3 = deconv_relu(n.relu6, 128)
    n.concate3 = L.Concate(n.uprelu3, n.relu2_2, concat_param=dict(axis=1))
    n.conv7, n.relu7 = conv_relu(n.concate3, 64)

    n.upconv4, n.uprelu4 = deconv_relu(n.relu7, 64)
    n.concate4 = L.Concate(n.uprelu4, n.relu1_2, concat_param=dict(axis=1))
    n.conv8, n.relu8 = conv_relu(n.concate4, 68)

    if split=='train':
        n.loss = L.SoftmaxWithLoss(n.conv8, n.label)
    else:
        n.score = L.Softmax(n.conv8)

    return n.to_proto()

def make_net():
    with open('train_val.prototxt', 'w') as f:
        f.write(str(cnn_dnn('train')))

    with open('deploy.prototxt', 'w') as f:
        f.write(str(cnn_dnn('test')))

if __name__ == '__main__':
    make_net()
    print 'Done!'