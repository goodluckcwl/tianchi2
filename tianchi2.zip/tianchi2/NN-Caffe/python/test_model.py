import sys
sys.path.insert(0, '/home/chenweiliang/caffe-windows-ms/python')
import caffe
import numpy as np
import scipy.io as sio
import h5py
import pandas as pd


def apply_transform(Y, T):
    Y = Y * T['L'][0,0][0,0] + T['v'][0,0][0,0]
    return Y

data_dir = '../../dataset/traindata.mat'
data = sio.loadmat(data_dir)
test = data['test']
X = test['X'][0][0]
train = data['train']
X_tr = train['X'][0][0]
Y_tr = train['Y'][0][0]
T = data['train']['T'][0][0]

# Load model
model_weights = '../nn-net-prelu/model/step1_iter_30000.caffemodel'
model_def = '../nn-net-prelu/deploy.prototxt'

caffe.set_mode_gpu()
net = caffe.Net(model_def, model_weights, caffe.TEST)
M, N = X_tr.shape
X_tr = X_tr.reshape(M, 1, 1, N)
X = X.reshape(221, 1, 1, N)
net.blobs['x'].reshape(221, 1, 1, N)
net.blobs['x'].data[...] = X
pred = net.forward()

#Y_tr_pred = pred['pred']
#sio.savemat('Y_tr_pred.mat', {'Y_tr_pred':Y_tr_pred})

Y_test = pred['pred']
sio.savemat('Y_test.mat', {'Y_test':Y_test})



# Read validation data
data_valid = h5py.File('../nn-net-prelu/hdf5/val.h5', 'r')
X_valid = np.array(data_valid['x'])
Y_valid = np.array(data_valid['y'])
Y_valid = Y_valid.reshape((Y_valid.shape[0]))
net.blobs['x'].reshape(X_valid.shape[0], X_valid.shape[1], X_valid.shape[2], X_valid.shape[3])
net.blobs['x'].data[...] = X_valid
Y_pred_valid = net.forward()['pred']
Y_pred_valid = Y_pred_valid.reshape((Y_pred_valid.shape[0]))
Y_pred_valid = apply_transform(Y_pred_valid, T)
Y_valid = apply_transform(Y_valid, T)
mse = np.sum(np.power(Y_valid - Y_pred_valid, 2))/len(Y_pred_valid)
print 'Validation RMSE: %f' % mse


# Save results
Y_test = Y_test.reshape((Y_test.shape[0]))
Y_test = apply_transform(Y_test, T)
testA_id = pd.read_csv('../../Data/testA.csv')['ID']
df_pred = pd.DataFrame({'ID': testA_id, 'prediction': Y_test[0:100]})
df_pred.to_csv('testA_nn_%f.csv'% mse, index = False)