clc;clear all;

opts.trainfile = '../dataset/traindata.mat';
opts.dataset_name = 'hdf5';
mkdir(opts.dataset_name);
load(opts.trainfile);

opts.num_samples = size(train.X, 1);
load(opts.trainfile);
X = train.X;
Y = train.Y;

%% Selcet some features
% I = randperm(size(X, 2));
% select_num = 100;
% X = X(:, I(1:select_num));

%% train/val
opts.num_train = 450;
opts.num_val = 50;
%% shuffle
I = randperm(opts.num_samples);
X_tr = X(I(1:opts.num_train),:);
X_val = X(I(opts.num_train +1:end),:);
Y_tr = Y(I(1:opts.num_train),:);
Y_val = Y(I(opts.num_train +1:end),:);
num_feats = size(X, 2);


%% Hdf5
opts.batch_size = 20000;

disp(['--------Writing hdf5 data----------']);
disp(opts);
fid = fopen([opts.dataset_name '/train.txt'], 'w');

for i = 1:ceil(opts.num_train/opts.batch_size)
    %% n,c,h,w
    if i == ceil(opts.num_train/opts.batch_size)
        I = (i-1)*opts.batch_size+1:opts.num_train;
    else
        I = (i-1)*opts.batch_size+1:i*opts.batch_size;
    end
    X_blobs_tr = data_list_to_blob(num2cell(X_tr(I, :),2));
    Y_blobs_tr = data_list_to_blob(num2cell(Y_tr(I, :),2));
    name = fullfile(opts.dataset_name, ['train' num2str(i) '.h5']);
    h5create(name,'/x',[num_feats 1 1 length(I)],'Datatype','single');
    h5create(name,'/y',[1 1 1 length(I)],'Datatype','single');
    h5write(name,'/x', X_blobs_tr);
    h5write(name, '/y', Y_blobs_tr);
%     fprintf(fid, '%s\n', name);
    disp(['Write ' name]);
end
fclose(fid);

X_blobs_val = data_list_to_blob(num2cell(X_val,2));
Y_blobs_val = data_list_to_blob(num2cell(Y_val,2));
h5create([opts.dataset_name '/val.h5'],'/x',[num_feats 1 1 length(Y_val)],'Datatype','single');
h5create([opts.dataset_name '/val.h5'],'/y',[1 1 1 length(Y_val)],'Datatype','single');
h5write([opts.dataset_name '/val.h5'],'/x', X_blobs_val);
h5write([opts.dataset_name '/val.h5'], '/y', Y_blobs_val);
