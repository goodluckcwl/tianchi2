clc;clear all;
load Y_testA.mat
list = importdata('../testA-muban.csv');
fid = fopen('testA.csv', 'w');

for i=1:100
    line = [list{i}, ',', num2str(Y_a(i))];
    fprintf(fid, '%s\n', line);
end
fclose(fid);
'Done!'