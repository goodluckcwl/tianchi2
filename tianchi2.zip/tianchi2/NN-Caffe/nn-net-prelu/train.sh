#!/bin/bash

CAFFE=~/caffe-windows-ms/build/tools/caffe
TOOLS=$CAFFE/build/tools


#  lr = 0.003
#$CAFFE train --solver=solver.prototxt --gpu 0 2>&1  | tee ./log/step1.log
# lr = 0.003
$CAFFE train --solver=solver.prototxt --gpu 0 2>&1  | tee ./log/step2.log
